declare module "*.svg" {

  const content: any;

  export default content;

}

declare module "*.jpg" {

  const content: any;

  export default content;

}
declare module "*.png" {
  const src: any
  export default src
}

declare module "*.PNG" {
  const src: any
  export default src
}