//   <reference types="react-scripts" />
declare module '*.mp3';
declare module "*.png";
declare module "*.svg";
declare module "*.jpeg";
declare module "*.jpg";