// import React from "react";
// import profile from '../../assets/profile.png';
// import "../Header/HeaderComponent.scss"
// function GreetingSection(props: any) {
//     return (


//         <div className="card-3">
//             <div className="header-profile">
//                 <span className="header-profile--greet">
//                     Hi {props.parsedDatapic.name}
//                 </span>
//                 <div className="header-profile--img">
//                     {props.parsedDatapic.url === "" ? (
//                         <img src={profile} width="40px" height="40px" alt="profile"></img>
//                     ) : (
//                         <img
//                             src={props.parsedDatapic.url}
//                             width="40px"
//                             height="40px"
//                             alt="profile"
//                         ></img>
//                     )}
//                 </div>
//             </div>

//         </div>
//     );
// }
// export default GreetingSection