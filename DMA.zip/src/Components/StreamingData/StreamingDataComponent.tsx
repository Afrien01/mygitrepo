import React from "react";
function StreamingDataComponent() {
    return (
        <div>

        </div>);

}
export default StreamingDataComponent
